package org.james.vodafone.peoplecontentslurp;

import java.util.List;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.widget.TextView;

import com.vodafone360.people.datatypes.Identity;
import com.vodafone360.people.datatypes.LoginDetails;
import com.vodafone360.people.datatypes.RegistrationDetails;
import com.vodafone360.people.service.aidl.IDatabaseSubscriber;
import com.vodafone360.people.service.aidl.IDatabaseSubscriptionService;

public class ContentSlurp extends Activity {

    private static final String TAG = "ContentSlurp";
    private final String SUBSCRIPTION_IDENTIFIER = "org.james.vodafone.peoplecontentslurp.ContentSlurp";

    private IDatabaseSubscriptionService mPeopleService;

    //Instantiate the subscriber (which will handle incoming events)
    private IDatabaseSubscriber.Stub mServiceSubscriber = new IDatabaseSubscriber.Stub() {
        @Override
        public void handleEvent(Message msg) throws RemoteException {
            Log.i(TAG, "Got message from 360 service"
                    + "(Message Code: " + msg.toString()
                    + " || Message Description: " + msg.describeContents() + ")");

        }

        /*
         * This is the bit of code that receives a callback from the IPeopleService
         * telling us that it's now ready to receive calls.
         * 
         * (non-Javadoc)
         * @see org.james.idl.IDatabaseSubscriber#onServiceReady()
         */
        public void onServiceReady(){
            Log.i(TAG, "Service ready; going to use it now.");
            try {
                Log.i(TAG, "Starting codeblock to test the service");
                anyOtherCode();
            } catch (RemoteException e) {
                Log.e(TAG, "Got a remote exception calling the service");
                e.printStackTrace();
            } finally {
                Log.i(TAG, "Finished testing the subscription service from callback");
            }
        }
    };

    private Uri mTimelineUri;

    private static final Uri PROVIDER_URI
    = Uri.parse(com.vodafone360.people.service.aidl.Intents.DATABASE_URI);


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        mTimelineUri = Uri.withAppendedPath(PROVIDER_URI, "Activities");
        Uri contactSummaryUri = Uri.withAppendedPath(PROVIDER_URI, "ContactSummary");

        Intent serviceIntent = com.vodafone360.people.service.aidl.Intents.SERVICE_INTENT;
        startService(serviceIntent); //Start the service separately so it doesn't shut down unexpectedly

        if(!bindService(serviceIntent, serviceConnection, 0)){
            Log.e(TAG,"Failed to start subscription service; dumping list of available services:");
            List<ResolveInfo> intentServices = getPackageManager().queryIntentServices(new Intent().addCategory(Intent.CATEGORY_DEFAULT), 0);
            for(ResolveInfo r : intentServices){
                Log.e(TAG, r.toString());
            }
        }


        //Get info from the timeline table of the database

        Cursor timelineCursor = managedQuery(mTimelineUri,null,null,null,null);

        if(timelineCursor == null){
            throw new NullPointerException("Couldn't bind timeline cursor");
        } else {
            Log.i(TAG,"Got cursor: " + timelineCursor);
        }

        if(timelineCursor.moveToFirst()){
            Log.i(TAG,"Put Cursor to first position; beginning output of data");
            do{
                String record = "[";
                for(int i=0;i<timelineCursor.getColumnCount();i++){
                    if(timelineCursor.getString(i) != null){
                        record += timelineCursor.getColumnName(i) + ":" + timelineCursor.getString(i) + ", ";
                    }
                }
                record += "]";
                Log.v(TAG,record);

                TextView text = (TextView) this.findViewById(R.id.empty);
                text.append("\n" + timelineCursor.getString(timelineCursor.getColumnIndex("contactlocalid")) + " : " + timelineCursor.getString(timelineCursor.getColumnIndex("contactname")));


            } while(timelineCursor.moveToNext());
        } else {
            Log.e(TAG,"Could not move cursor to first entry"
                    + " (Cursor count: " + Integer.toString(timelineCursor.getCount()) + ")"
            );
            Log.e(TAG,"Dumping column names:");
            for(int i=0;i<timelineCursor.getColumnCount();i++){
                Log.e(TAG, "    Col"+i+(i<10 ? " " : "") + ": "+timelineCursor.getColumnName(i));
            }
        }


    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        Log.i(TAG,"onDestroy()");
        try{
            this.unbindService(serviceConnection);
        } catch (IllegalArgumentException e){
            Log.e(TAG,"Tried to unbindService(" + serviceConnection + ") but service was not registered");
        }
        try {
            if (mPeopleService != null) {
                mPeopleService.unsubscribe(SUBSCRIPTION_IDENTIFIER);
            }
            Log.i(TAG,"Unsubscribed from subscription service");
        } catch (RemoteException e) {
            Log.e(TAG,"Trying to unsubscribe, got RemoteException");
            e.printStackTrace();
        }

    }


    @Override
    protected void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
        Log.i(TAG,"onPause()");

    }


    @Override
    protected void onResume() {
        super.onResume();

        if(mPeopleService!=null){
            try {
                mPeopleService.subscribe(SUBSCRIPTION_IDENTIFIER, mServiceSubscriber);
            } catch (RemoteException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    ServiceConnection serviceConnection = new ServiceConnection(){


        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mPeopleService = IDatabaseSubscriptionService.Stub.asInterface(service);
            Log.i(TAG, "onServiceConnected["+name+","+service+"]");
            //Subscribe to the service now that we've received it

            Log.i(TAG,"subscriptionService: " + mPeopleService);
            Log.i(TAG,"service: " + service);
            Log.i(TAG,"mServiceSubscriber: " + mServiceSubscriber.toString());

            try{
                if(mPeopleService.subscribe(SUBSCRIPTION_IDENTIFIER, mServiceSubscriber)){
                    Log.i(TAG, 
                    "Successfully subscribed to get push notifications from the 360 People Service");
                    anyOtherCode();
                } else {
                    Log.i(TAG, "Something went wrong trying to subscribe (waiting for a callback now)");
                }

            } catch(RemoteException e){
                Log.e(TAG, "Got a RemoteException");
            } catch(NullPointerException e){
                Log.e(TAG, "Got a NullPointerException while trying to subscribe");
                Log.e(TAG, 
                "    Have you checked that the AIDL files are identical between the service and client?");
                Log.e(TAG,
                "   Have you checked that mPeopleService is not null in the service?");
            }




        }


        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.i(TAG,"onServiceDisconnected()");
            mPeopleService = null;
        }

    };



    private void anyOtherCode() throws RemoteException {
        try{
            Log.i(TAG, "Dumping some info:");


            Log.i(TAG, "     getLoginRequired() -> " + Boolean.toString(mPeopleService.getLoginRequired()));
            // Log in to the service - you'll have to set some of these details...
            if (mPeopleService.getLoginRequired()) {
                LoginDetails loginDetails = new LoginDetails();
                loginDetails.mUsername="";
                loginDetails.mMobileNo="";
                loginDetails.mPassword="";
                loginDetails.mRememberMe=true;
                Log.i(TAG, "     logon(" + loginDetails + ")");
                mPeopleService.logon(loginDetails);
                mPeopleService.startContactSync();
                mPeopleService.startStatusesSync();

            }

            Log.i(TAG, "     checkForUpdates() ...");
            mPeopleService.checkForUpdates();
            //Log.i(TAG,"     sendMessage(toLocalContactId=228,messageBody=\"Hello, world\",networkId=0) ...");
            //mPeopleService.sendMessage(228L, "Let me know whether this harcoded trial works?", 0);
            Log.i(TAG, "     getStatuses() ...");
            mPeopleService.getStatuses();
            Log.i(TAG, "     uploadMyStatus(\"Hello, world\") ...");
            mPeopleService.uploadMyStatus("Hello World");

            Log.i(TAG, "     getAvailableThirdPartyIdentities() ...");
            for (Identity i : mPeopleService.getAvailableThirdPartyIdentities()) {
                Log.v(TAG, "IDENTITY: " + i.toString());
            }

            for(long i=2; i<5; i++){
                Log.i(TAG, "     getUserPresenceStatusByLocalContactId("+i+")");
                Log.i(TAG, mPeopleService.getUserPresenceStatusByLocalContactId(i).toString());
            }


        } catch (NullPointerException e) {
            Log.e(TAG, "Caught a NullPointerException after subscribing, running anyOtherCode()");
            e.printStackTrace();
        }

    }
}