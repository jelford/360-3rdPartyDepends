package org.james.idl;

public class Intents {
    public static final String SUBSCRIPTION_SERVICE = "org.james.idl.IdlPeopleInterface";
}
